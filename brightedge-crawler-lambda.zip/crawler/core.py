"""
Core web crawler functionality for BrightEdge assignment.
Handles URL fetching, HTML parsing, and metadata extraction.
"""

import requests
import re
import time
from typing import Dict, Optional, List
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class WebCrawler:
    """
    Core web crawler class that fetches URLs and extracts metadata.
    """
    
    def __init__(self, timeout: int = 30, max_retries: int = 3, delay: float = 1.0):
        """
        Initialize the web crawler.
        
        Args:
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
            delay: Delay between requests in seconds
        """
        self.timeout = timeout
        self.max_retries = max_retries
        self.delay = delay
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        # Domain rate limiting
        self.domain_delays = {}
        
    def fetch_url(self, url: str) -> Optional[requests.Response]:
        """
        Fetch a URL with retry logic and error handling.
        
        Args:
            url: The URL to fetch
            
        Returns:
            Response object or None if failed
        """
        # Check robots.txt compliance (but be more lenient for demo)
        if not self._check_robots_txt(url):
            logger.warning(f"Robots.txt disallows crawling: {url}")
            # For demo purposes, continue anyway but log the warning
            # In production, this would be more strict
            
        # Apply rate limiting
        self._apply_rate_limit(url)
        
        for attempt in range(self.max_retries):
            try:
                logger.info(f"Fetching URL: {url} (attempt {attempt + 1})")
                response = self.session.get(url, timeout=self.timeout)
                response.raise_for_status()
                return response
                
            except requests.exceptions.RequestException as e:
                logger.error(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.delay * (attempt + 1))  # Exponential backoff
                else:
                    logger.error(f"Failed to fetch URL after {self.max_retries} attempts: {url}")
                    return None
                    
    def _check_robots_txt(self, url: str) -> bool:
        """
        Check robots.txt for crawling permissions.
        
        Args:
            url: The URL to check
            
        Returns:
            True if crawling is allowed, False otherwise
        """
        try:
            parsed_url = urlparse(url)
            robots_url = f"{parsed_url.scheme}://{parsed_url.netloc}/robots.txt"
            
            response = self.session.get(robots_url, timeout=10)
            if response.status_code == 200:
                robots_content = response.text.lower()
                # More specific robots.txt parsing
                if 'disallow: /' in robots_content and 'user-agent: *' in robots_content:
                    return False
                # Check for specific user-agent rules
                if 'user-agent: *' in robots_content and 'disallow: /' in robots_content:
                    return False
                    
        except Exception as e:
            logger.warning(f"Could not check robots.txt for {url}: {e}")
            
        return True
        
    def _apply_rate_limit(self, url: str):
        """
        Apply rate limiting per domain.
        
        Args:
            url: The URL being fetched
        """
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        
        if domain in self.domain_delays:
            time_since_last = time.time() - self.domain_delays[domain]
            if time_since_last < self.delay:
                sleep_time = self.delay - time_since_last
                logger.info(f"Rate limiting: sleeping {sleep_time:.2f}s for domain {domain}")
                time.sleep(sleep_time)
                
        self.domain_delays[domain] = time.time()
        
    def extract_metadata(self, html_content: str, url: str) -> Dict:
        """
        Extract metadata from HTML content.
        
        Args:
            html_content: Raw HTML content
            url: Source URL
            
        Returns:
            Dictionary containing extracted metadata
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Extract title
        title = self._extract_title(soup)
        
        # Extract description
        description = self._extract_description(soup)
        
        # Extract body content
        body = self._extract_body(soup)
        
        # Classify content
        topics = self._classify_content(title, description, body, url)
        
        return {
            'url': url,
            'title': title,
            'description': description,
            'body': body,
            'topics': topics,
            'extracted_at': time.time()
        }
        
    def _extract_title(self, soup: BeautifulSoup) -> str:
        """
        Extract page title from HTML.
        
        Args:
            soup: BeautifulSoup object
            
        Returns:
            Page title or empty string
        """
        # Try title tag first
        title_tag = soup.find('title')
        if title_tag and title_tag.get_text().strip():
            return title_tag.get_text().strip()
            
        # Try h1 tag as fallback
        h1_tag = soup.find('h1')
        if h1_tag and h1_tag.get_text().strip():
            return h1_tag.get_text().strip()
            
        return ""
        
    def _extract_description(self, soup: BeautifulSoup) -> str:
        """
        Extract page description from meta tags.
        
        Args:
            soup: BeautifulSoup object
            
        Returns:
            Page description or empty string
        """
        # Try meta description
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc and meta_desc.get('content'):
            return meta_desc.get('content').strip()
            
        # Try Open Graph description
        og_desc = soup.find('meta', attrs={'property': 'og:description'})
        if og_desc and og_desc.get('content'):
            return og_desc.get('content').strip()
            
        # Try Twitter description
        twitter_desc = soup.find('meta', attrs={'name': 'twitter:description'})
        if twitter_desc and twitter_desc.get('content'):
            return twitter_desc.get('content').strip()
            
        return ""
        
    def _extract_body(self, soup: BeautifulSoup) -> str:
        """
        Extract main body content from HTML.
        
        Args:
            soup: BeautifulSoup object
            
        Returns:
            Cleaned body text
        """
        # Remove script and style elements
        for script in soup(["script", "style", "nav", "header", "footer", "aside"]):
            script.decompose()
            
        # Try to find main content area
        main_content = soup.find('main') or soup.find('article') or soup.find('div', class_=re.compile(r'main|content|post|article', re.I))
        
        if main_content:
            text = main_content.get_text()
        else:
            # Fallback to body
            text = soup.get_text()
            
        # Clean up whitespace
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)
        
        return text[:5000]  # Limit body length
        
    def _classify_content(self, title: str, description: str, body: str, url: str) -> List[str]:
        """
        Classify content into topics based on keywords and URL patterns.
        
        Args:
            title: Page title
            description: Page description
            body: Page body content
            url: Source URL
            
        Returns:
            List of topic classifications
        """
        topics = []
        content = f"{title} {description} {body}".lower()
        
        # E-commerce patterns
        ecommerce_keywords = ['buy', 'purchase', 'price', 'sale', 'discount', 'shipping', 'cart', 'checkout', 'product']
        if any(keyword in content for keyword in ecommerce_keywords) or '/dp/' in url or '/product/' in url:
            topics.append('e-commerce')
            
        # News patterns
        news_keywords = ['news', 'breaking', 'update', 'report', 'announcement', 'press', 'journalism']
        if any(keyword in content for keyword in news_keywords) or 'news' in url.lower():
            topics.append('news')
            
        # Blog patterns
        blog_keywords = ['blog', 'post', 'article', 'story', 'experience', 'tutorial', 'guide', 'how-to']
        if any(keyword in content for keyword in blog_keywords) or '/blog/' in url or '/post/' in url:
            topics.append('blog')
            
        # Technology patterns
        tech_keywords = ['technology', 'software', 'app', 'digital', 'online', 'web', 'internet', 'computer']
        if any(keyword in content for keyword in tech_keywords):
            topics.append('technology')
            
        # If no specific topics found, classify as general
        if not topics:
            topics.append('general')
            
        return topics
        
    def crawl(self, url: str) -> Optional[Dict]:
        """
        Main crawling method that fetches URL and extracts metadata.
        
        Args:
            url: The URL to crawl
            
        Returns:
            Dictionary with extracted metadata or None if failed
        """
        try:
            # Fetch the URL
            response = self.fetch_url(url)
            if not response:
                return None
                
            # Extract metadata
            metadata = self.extract_metadata(response.text, url)
            
            logger.info(f"Successfully crawled: {url}")
            return metadata
            
        except Exception as e:
            logger.error(f"Error crawling {url}: {e}")
            return None 