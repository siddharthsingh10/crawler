import json
import os
from typing import Any, Dict, Optional

from crawler.core import WebCrawler


def _cors_headers() -> Dict[str, str]:
    return {
        "Access-Control-Allow-Origin": os.environ.get("CORS_ALLOW_ORIGIN", "*"),
        "Access-Control-Allow-Methods": "GET,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type,X-Api-Key",
        "Content-Type": "application/json",
    }


def _bad_request(message: str, status_code: int = 400) -> Dict[str, Any]:
    return {"statusCode": status_code, "headers": _cors_headers(), "body": json.dumps({"error": message})}


def handler(event: Dict[str, Any], context: Optional[Any] = None) -> Dict[str, Any]:
    """
    AWS Lambda handler that accepts GET /crawl?url=<URL> and returns extracted metadata as JSON.
    """
    # Health check path or preflight
    if event.get("httpMethod") == "OPTIONS":
        return {"statusCode": 200, "headers": _cors_headers(), "body": json.dumps({"ok": True})}

    params = (event.get("queryStringParameters") or {})
    url = params.get("url") if isinstance(params, dict) else None

    if not url or not isinstance(url, str) or not url.startswith("http"):
        return _bad_request("Missing or invalid 'url' query parameter")

    timeout = int(os.environ.get("CRAWLER_TIMEOUT", "30"))
    retries = int(os.environ.get("CRAWLER_MAX_RETRIES", "3"))
    delay = float(os.environ.get("CRAWLER_DELAY", "1.0"))

    crawler = WebCrawler(timeout=timeout, max_retries=retries, delay=delay)

    result = crawler.crawl(url)
    if result is None:
        return _bad_request("Failed to crawl the provided URL", status_code=502)

    return {"statusCode": 200, "headers": _cors_headers(), "body": json.dumps(result, default=str)}
