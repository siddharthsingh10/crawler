import json
from lambda_handler import handler


def invoke(url: str):
    event = {
        "httpMethod": "GET",
        "path": "/crawl",
        "queryStringParameters": {"url": url},
        "headers": {"x-api-key": "test"},
    }
    response = handler(event, None)
    print("Status:", response.get("statusCode"))
    print("Headers:", json.dumps(response.get("headers"), indent=2))
    print("Body:")
    print(json.dumps(json.loads(response.get("body", "{}")), indent=2))


if __name__ == "__main__":
    # Try with a friendly URL
    invoke("https://example.com")
